# CodeAlpha AI Internship – Submission

| Task | Repository folder | Port |
|------|-------------------|------|
| Task 1: Language Translation Tool | `CodeAlpha_LanguageTranslationTool/` | 5001 |
| Task 2: Chatbot for FAQs | `CodeAlpha_FAQChatbot/` | 5000 |

Each folder is a standalone project with its own README, requirements and tests. For GitHub, upload each folder as its own repository named exactly as the folder (`CodeAlpha_ProjectName`). Full documentation is in `Project_Documentation.docx`.
