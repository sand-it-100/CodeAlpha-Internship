import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from chatbot import FAQChatbot, preprocess, NO_MATCH

BOT = FAQChatbot(Path(__file__).resolve().parents[1] / "data" / "faqs.json")


class ChatbotTests(unittest.TestCase):
    def test_preprocess_removes_stopwords_and_punctuation(self):
        out = preprocess("How do I submit my task?!")
        self.assertNotIn("how", out.split()); self.assertIn("submit", out)

    def test_submission_question(self):
        self.assertIn("submission form", BOT.ask("where do I submit the finished task")["answer"])

    def test_certificate_question(self):
        self.assertIn("certificate", BOT.ask("will I get certificate if only one task done")["answer"].lower())

    def test_contact_question(self):
        self.assertIn("services@codealpha.tech", BOT.ask("how to contact you by email")["answer"])

    def test_unknown_question(self):
        self.assertEqual(BOT.ask("what is the weather on mars")["answer"], NO_MATCH)

    def test_empty_input(self):
        self.assertEqual(BOT.ask("   ")["answer"], NO_MATCH)


if __name__ == "__main__":
    unittest.main()
