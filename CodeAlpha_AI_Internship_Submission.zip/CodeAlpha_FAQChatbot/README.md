# CodeAlpha_FAQChatbot

**CodeAlpha AI Internship – Task 2: Chatbot for FAQs**

A Flask-based chatbot that answers questions about the CodeAlpha internship program. It preprocesses text with NLP techniques and finds the closest FAQ using TF-IDF vectors and cosine similarity.

## Features
- FAQ knowledge base in `data/faqs.json` (easy to edit or replace with any topic)
- Text preprocessing: lowercasing, punctuation removal, tokenization, stop-word removal, stemming (NLTK Porter stemmer if installed)
- Cosine similarity matching with unigram + bigram TF-IDF
- Confidence threshold with a polite fallback for unknown questions
- Simple chat web UI (HTML/CSS/JS) and JSON API

## How it works
1. Each FAQ (question + answer) is preprocessed and converted to a TF-IDF vector at startup.
2. The user message goes through the same preprocessing and vectorization.
3. Cosine similarity is computed against every FAQ; the highest score wins.
4. If the score is below the threshold (0.2), a fallback message is returned.

## Project structure
```
CodeAlpha_FAQChatbot/
├── app.py            # Flask app and /chat endpoint
├── chatbot.py        # preprocessing + similarity engine
├── data/faqs.json    # FAQ dataset
├── templates/index.html
├── static/style.css
├── tests/test_chatbot.py
└── requirements.txt
```

## Setup and run
```bash
python -m venv venv
venv\Scripts\activate        # Windows  (Linux/macOS: source venv/bin/activate)
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## API
`POST /chat` with `{"message": "How do I submit my task?"}` returns
`{"answer": "...", "matched_question": "...", "score": 0.52}`

## Tests
```bash
python -m unittest discover -s tests -v
```

## Customizing
Edit `data/faqs.json` (list of `{"question", "answer"}`) to build a bot for any product or topic. Tune `threshold` in `FAQChatbot(...)`.

## Tech stack
Python, Flask, scikit-learn, NLTK (optional), HTML/CSS/JavaScript
