"""FAQ matching engine: NLP preprocessing + TF-IDF cosine similarity."""
import json
import re
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

try:  # NLTK is optional; its Porter stemmer needs no extra data download.
    from nltk.stem import PorterStemmer
    _stem = PorterStemmer().stem
except Exception:  # pragma: no cover
    def _stem(word):
        return word

# Small built-in stop-word list so the bot works without downloading NLTK data.
STOPWORDS = set("""a an the is are was were be been am do does did to of in on at for from by with
and or but if then so as it its this that these those i me my we our you your can could should would
will shall may might about into out up down how what which who whom when where why get have has had
please tell""".split())

NO_MATCH = ("Sorry, I could not find a good answer to that. Try rephrasing your question, "
            "or contact services@codealpha.tech.")


def preprocess(text: str) -> str:
    """Lowercase, remove punctuation, tokenize, drop stop words, stem."""
    text = re.sub(r"[^a-z0-9\s]", " ", text.lower())
    tokens = [t for t in text.split() if t not in STOPWORDS]
    return " ".join(_stem(t) for t in tokens)


class FAQChatbot:
    def __init__(self, faq_path, threshold: float = 0.2):
        self.threshold = threshold
        self.faqs = json.loads(Path(faq_path).read_text(encoding="utf-8"))
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2))
        corpus = [preprocess(f["question"] + " " + f["answer"]) for f in self.faqs]
        self.matrix = self.vectorizer.fit_transform(corpus)

    def ask(self, user_text: str) -> dict:
        """Return best answer, matched question and similarity score."""
        cleaned = preprocess(user_text or "")
        if not cleaned:
            return {"answer": NO_MATCH, "matched_question": None, "score": 0.0}
        scores = cosine_similarity(self.vectorizer.transform([cleaned]), self.matrix)[0]
        best = int(scores.argmax())
        score = float(scores[best])
        if score < self.threshold:
            return {"answer": NO_MATCH, "matched_question": None, "score": round(score, 3)}
        return {"answer": self.faqs[best]["answer"],
                "matched_question": self.faqs[best]["question"],
                "score": round(score, 3)}
