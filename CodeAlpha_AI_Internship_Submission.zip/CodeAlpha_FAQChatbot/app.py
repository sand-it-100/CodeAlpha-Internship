from pathlib import Path

from flask import Flask, jsonify, render_template, request

from chatbot import FAQChatbot

BASE = Path(__file__).parent
app = Flask(__name__)
bot = FAQChatbot(BASE / "data" / "faqs.json")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    return jsonify(bot.ask(data.get("message", "")))


if __name__ == "__main__":
    app.run(debug=True, port=5000)
