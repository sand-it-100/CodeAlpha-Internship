from flask import Flask, jsonify, render_template, request

from translator import LANGUAGES, TranslationError, translate

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html", languages=LANGUAGES)


@app.route("/translate", methods=["POST"])
def translate_route():
    data = request.get_json(silent=True) or {}
    try:
        out = translate(data.get("text"), data.get("source", "auto"), data.get("target", "en"))
        return jsonify({"translation": out})
    except TranslationError as err:
        return jsonify({"error": str(err)}), 400


if __name__ == "__main__":
    app.run(debug=True, port=5001)
