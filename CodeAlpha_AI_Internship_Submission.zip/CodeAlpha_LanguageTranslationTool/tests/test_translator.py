import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from translator import translate, TranslationError
from app import app


def fake(text, s, t):
    return f"[{t}] {text}"


def broken(text, s, t):
    raise RuntimeError("offline")


class TranslatorTests(unittest.TestCase):
    def test_success(self):
        self.assertEqual(translate("hello", "en", "hi", backend=fake), "[hi] hello")

    def test_empty(self):
        with self.assertRaises(TranslationError): translate("  ", "en", "hi", backend=fake)

    def test_same_language_returns_input(self):
        self.assertEqual(translate("hi", "en", "en", backend=fake), "hi")

    def test_invalid_language(self):
        with self.assertRaises(TranslationError): translate("hi", "en", "xx", backend=fake)

    def test_too_long(self):
        with self.assertRaises(TranslationError): translate("a" * 5001, "en", "hi", backend=fake)

    def test_backend_failure_is_wrapped(self):
        with self.assertRaises(TranslationError): translate("hi", "en", "hi", backend=broken)

    def test_route_validation(self):
        c = app.test_client()
        self.assertEqual(c.post("/translate", json={"text": "", "target": "hi"}).status_code, 400)
        self.assertEqual(c.get("/").status_code, 200)


if __name__ == "__main__":
    unittest.main()
