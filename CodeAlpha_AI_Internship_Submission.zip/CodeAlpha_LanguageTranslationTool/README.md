# CodeAlpha_LanguageTranslationTool

**CodeAlpha AI Internship – Task 1: Language Translation Tool**

A web app where the user enters text, selects source and target languages, and gets the translation instantly. Translation uses Google Translate through the `deep-translator` library (no API key required).

## Features
- Text input with source language (including auto-detect) and target language selection
- 20+ languages including Hindi, Bengali, Tamil, Spanish, French, German, Japanese, Arabic
- Clear output panel, language swap button
- **Copy** to clipboard and **Listen** (text-to-speech using the browser Speech Synthesis API)
- Input validation (empty text, 5000 character limit, unsupported language) and friendly error messages

## Project structure
```
CodeAlpha_LanguageTranslationTool/
├── app.py             # Flask app and /translate endpoint
├── translator.py      # translation service with validation and error handling
├── templates/index.html
├── static/style.css
├── tests/test_translator.py
└── requirements.txt
```

## Setup and run
```bash
python -m venv venv
venv\Scripts\activate        # Windows  (Linux/macOS: source venv/bin/activate)
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5001 (an internet connection is required for translation).

## API
`POST /translate` with `{"text": "Hello", "source": "en", "target": "hi"}` returns `{"translation": "..."}`; errors return HTTP 400 with `{"error": "..."}`.

## Tests
Unit tests use a mock backend, so they run offline:
```bash
python -m unittest discover -s tests -v
```

## Using an official API instead
`translate()` accepts a `backend` function. To use the Google Cloud Translation or Microsoft Translator API, write a function `(text, source, target) -> str` that calls it and pass it in; nothing else changes.

## Tech stack
Python, Flask, deep-translator, HTML/CSS/JavaScript
