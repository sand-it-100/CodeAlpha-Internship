"""Translation service. Uses Google Translate through the `deep-translator` package
(no API key needed). The backend is injectable so the logic can be unit-tested offline."""

LANGUAGES = {
    "auto": "Detect language", "en": "English", "hi": "Hindi", "bn": "Bengali", "ta": "Tamil",
    "te": "Telugu", "mr": "Marathi", "gu": "Gujarati", "pa": "Punjabi", "ur": "Urdu",
    "es": "Spanish", "fr": "French", "de": "German", "it": "Italian", "pt": "Portuguese",
    "ru": "Russian", "ja": "Japanese", "ko": "Korean", "zh-CN": "Chinese (Simplified)",
    "ar": "Arabic", "tr": "Turkish",
}
MAX_CHARS = 5000


class TranslationError(Exception):
    pass


def _google_backend(text, source, target):
    from deep_translator import GoogleTranslator  # imported lazily
    return GoogleTranslator(source=source, target=target).translate(text)


def translate(text, source, target, backend=_google_backend):
    text = (text or "").strip()
    if not text:
        raise TranslationError("Please enter some text to translate.")
    if len(text) > MAX_CHARS:
        raise TranslationError(f"Text is too long (max {MAX_CHARS} characters).")
    if source not in LANGUAGES or target not in LANGUAGES or target == "auto":
        raise TranslationError("Unsupported language selection.")
    if source == target:
        return text
    try:
        result = backend(text, source, target)
    except Exception as exc:
        raise TranslationError("Translation service unavailable. Check your internet connection and try again.") from exc
    if not result:
        raise TranslationError("No translation returned.")
    return result
